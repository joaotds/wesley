<?php
    include_once(__DIR__ . "/../include/header.php");
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>Listagem de Alunos</h2>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Nome</th>
            <th>Idade</th>
            <th>Estrangeiro</th>
            <th>Curso</th>
            <th>Ações</th>
        </tr>

        <?php foreach ($alunos as $aluno): ?>
            <tr>
                <td><?php echo $aluno['id']; ?></td>
                <td><?php echo $aluno['nome']; ?></td>
                <td><?php echo $aluno['idade']; ?></td>
                <td><?php echo $aluno['estrangeiro'] ? 'Sim' : 'Não'; ?></td>
                <td><?php echo $aluno['curso']; ?></td>
                <td><!-- A --></td>
            </tr>
        <?php endforeach; ?>
    </table>

    <?php include_once(__DIR__ . "/../include/footer.php"); ?>
</body>
</html>
